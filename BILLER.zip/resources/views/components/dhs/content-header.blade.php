<div class="mb-3">
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6">
        </div><!-- /.col -->
        
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>