<?php if (isset($component)) { $__componentOriginale74a36bbe4c110c757bc794195f1a772 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale74a36bbe4c110c757bc794195f1a772 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale74a36bbe4c110c757bc794195f1a772)): ?>
<?php $attributes = $__attributesOriginale74a36bbe4c110c757bc794195f1a772; ?>
<?php unset($__attributesOriginale74a36bbe4c110c757bc794195f1a772); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale74a36bbe4c110c757bc794195f1a772)): ?>
<?php $component = $__componentOriginale74a36bbe4c110c757bc794195f1a772; ?>
<?php unset($__componentOriginale74a36bbe4c110c757bc794195f1a772); ?>
<?php endif; ?>

<body class="hold-transition dark-mode sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
    <div class="wrapper">

        <?php if (isset($component)) { $__componentOriginal5b1fda1569546060c763c3acc6e2c0f0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.preload','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.preload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0)): ?>
<?php $attributes = $__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0; ?>
<?php unset($__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b1fda1569546060c763c3acc6e2c0f0)): ?>
<?php $component = $__componentOriginal5b1fda1569546060c763c3acc6e2c0f0; ?>
<?php unset($__componentOriginal5b1fda1569546060c763c3acc6e2c0f0); ?>
<?php endif; ?>

        <!-- Navbar -->
        <?php if (isset($component)) { $__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043)): ?>
<?php $attributes = $__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043; ?>
<?php unset($__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043)): ?>
<?php $component = $__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043; ?>
<?php unset($__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043); ?>
<?php endif; ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php if (isset($component)) { $__componentOriginal4d3090547e878a0d007cc9b2331a31b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d3090547e878a0d007cc9b2331a31b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d3090547e878a0d007cc9b2331a31b9)): ?>
<?php $attributes = $__attributesOriginal4d3090547e878a0d007cc9b2331a31b9; ?>
<?php unset($__attributesOriginal4d3090547e878a0d007cc9b2331a31b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d3090547e878a0d007cc9b2331a31b9)): ?>
<?php $component = $__componentOriginal4d3090547e878a0d007cc9b2331a31b9; ?>
<?php unset($__componentOriginal4d3090547e878a0d007cc9b2331a31b9); ?>
<?php endif; ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper" style="margin-bottom: 50px">
            <!-- Content Header (Page header) -->
            <?php if (isset($component)) { $__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.content-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0)): ?>
<?php $attributes = $__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0; ?>
<?php unset($__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0)): ?>
<?php $component = $__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0; ?>
<?php unset($__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0); ?>
<?php endif; ?>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <!-- Info boxes -->

                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">

                                <div class="card-header">
                                    <h3 class="card-title">Data Paket PPPoE</h3>
                                    
                                </div>

                                <!-- /.card-header -->

                                <div class="card-body">
                                    <form action="<?php echo e(route('tambahpaket')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <!-- Pilihan MikroTik -->
                                        <!-- Pilihan MikroTik -->
                                        <div class="form-group">
                                            <label for="username">Pilih MikroTik ( Aktif )</label>
                                            <select class="form-control" id="username" name="username" required>
                                                <option value="">Pilih MikroTik</option>
                                                <?php $__currentLoopData = $mikrotikList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $router): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($router->id); ?>" data-site="<?php echo e($router->site); ?>">
                                                    <?php echo e($router->site); ?>

                                                </option>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <!-- Profil MikroTik -->
                                        <div class="form-group">
                                            <label for="profile">Pilih Profil</label>
                                            <select class="form-control" id="profile" name="profile" required>
                                                <option value="">Pilih Profil</option>
                                            </select>
                                            <small id="loadingIndicator" style="display:none;">Memuat profil
                                                MikroTik...</small>
                                        </div>

                                        <!-- Nama Paket -->
                                        <div class="form-group">
                                            <label for="packageName">Nama Paket</label>
                                            <div class="input-group mb-3">
                                                <input type="text" class="form-control" id="packageName"
                                                    name="namaPaket" placeholder="Nama Paket" required>
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="selectedMikrotik"></span>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Hidden Input untuk Nama MikroTik -->
                                        <input type="hidden" id="mikrotikSite" name="mikrotikSite">

                                        <!-- Harga Paket -->
                                        <div class="form-group">
                                            <label for="hargaPaket">Harga Paket</label>
                                            <input type="text" class="form-control" id="hargaPaket" name="hargaPaket"
                                                required
                                                oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 7)">
                                        </div>

                                        
                                        <button type="submit" class="btn btn-primary">Simpan Profil</button>
                                    </form>
                                </div>
                                <!-- /.card-body -->
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- /.content -->
        </div>


        <?php if (isset($component)) { $__componentOriginal10a5c05463c515701704e42d3b506416 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal10a5c05463c515701704e42d3b506416 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal10a5c05463c515701704e42d3b506416)): ?>
<?php $attributes = $__attributesOriginal10a5c05463c515701704e42d3b506416; ?>
<?php unset($__attributesOriginal10a5c05463c515701704e42d3b506416); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal10a5c05463c515701704e42d3b506416)): ?>
<?php $component = $__componentOriginal10a5c05463c515701704e42d3b506416; ?>
<?php unset($__componentOriginal10a5c05463c515701704e42d3b506416); ?>
<?php endif; ?>
    </div>
    <!-- ./wrapper -->

    <?php if (isset($component)) { $__componentOriginal4f8732821ff8626b580bba7a0c973801 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f8732821ff8626b580bba7a0c973801 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f8732821ff8626b580bba7a0c973801)): ?>
<?php $attributes = $__attributesOriginal4f8732821ff8626b580bba7a0c973801; ?>
<?php unset($__attributesOriginal4f8732821ff8626b580bba7a0c973801); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f8732821ff8626b580bba7a0c973801)): ?>
<?php $component = $__componentOriginal4f8732821ff8626b580bba7a0c973801; ?>
<?php unset($__componentOriginal4f8732821ff8626b580bba7a0c973801); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be)): ?>
<?php $attributes = $__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be; ?>
<?php unset($__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be)): ?>
<?php $component = $__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be; ?>
<?php unset($__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be); ?>
<?php endif; ?>
    <script>
        $(document).ready(function () {
            const mikrotikDropdown = $('#username');
            const profileDropdown = $('#profile');
            const loadingIndicator = $('#loadingIndicator');
            const selectedMikrotikSpan = $('#selectedMikrotik');
            const mikrotikSiteInput = $('#mikrotikSite');

            // Saat MikroTik dipilih
            mikrotikDropdown.on('change', function () {
                const selectedOption = mikrotikDropdown.find(':selected');
                const siteName = selectedOption.data('site');

                // Tampilkan nama MikroTik di sebelah input paket
                selectedMikrotikSpan.text(siteName || '');
                mikrotikSiteInput.val(siteName || '');

                // Kosongkan dropdown profil sebelum menambahkan data baru
                profileDropdown.empty().append('<option value="">Pilih Profil</option>');

                // Jika tidak ada pilihan MikroTik, hentikan eksekusi
                const username = $(this).val();
                if (!username) return;

                // Tampilkan loading indikator
                loadingIndicator.show();

                $.ajax({
                    url: '<?php echo e(route("getMikrotikProfiles")); ?>',
                    type: 'GET',
                    data: {
                        username: username
                    },
                    dataType: 'json',
                    success: function (response) {
                        loadingIndicator.hide();
                        if (response.status === 'success' && response.profiles.length > 0) {
                            response.profiles.forEach(profile => {
                                profileDropdown.append(
                                    `<option value="${profile.name}">${profile.name}</option>`
                                );
                            });
                        } else {
                            profileDropdown.append(
                                '<option value="">Tidak ada profil tersedia</option>');
                        }
                    },
                    error: function (xhr) {
                        loadingIndicator.hide();
                        let errorMessage = "Gagal memuat data profil";
                        if (xhr.responseJSON && xhr.responseJSON.message) {
                            errorMessage += ": " + xhr.responseJSON.message;
                        }
                        profileDropdown.append(`<option value="">${errorMessage}</option>`);
                    }
                });
            });
        });

    </script>

sesuaikan 
    
    <script>
        $(document).ready(function () {
            $('#pppoeTable').DataTable({
                responsive: true,
                autoWidth: false,
                language: {
                    url: "//cdn.datatables.net/plug-ins/1.13.6/i18n/Indonesian.json"
                }
            });
        });

    </script>



</body>

</html>
<?php /**PATH /home/lun4t1c/PROJECT/BILLER/resources/views/ROLE/MEMBER/IPLAN/PPPOE/tambahpaket.blade.php ENDPATH**/ ?>