<?php if (isset($component)) { $__componentOriginale74a36bbe4c110c757bc794195f1a772 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale74a36bbe4c110c757bc794195f1a772 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale74a36bbe4c110c757bc794195f1a772)): ?>
<?php $attributes = $__attributesOriginale74a36bbe4c110c757bc794195f1a772; ?>
<?php unset($__attributesOriginale74a36bbe4c110c757bc794195f1a772); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale74a36bbe4c110c757bc794195f1a772)): ?>
<?php $component = $__componentOriginale74a36bbe4c110c757bc794195f1a772; ?>
<?php unset($__componentOriginale74a36bbe4c110c757bc794195f1a772); ?>
<?php endif; ?>

<body class="hold-transition dark-mode sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
    <div class="wrapper">

        <?php if (isset($component)) { $__componentOriginal5b1fda1569546060c763c3acc6e2c0f0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.preload','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.preload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0)): ?>
<?php $attributes = $__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0; ?>
<?php unset($__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b1fda1569546060c763c3acc6e2c0f0)): ?>
<?php $component = $__componentOriginal5b1fda1569546060c763c3acc6e2c0f0; ?>
<?php unset($__componentOriginal5b1fda1569546060c763c3acc6e2c0f0); ?>
<?php endif; ?>
    
        <!-- Navbar -->
        <?php if (isset($component)) { $__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043)): ?>
<?php $attributes = $__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043; ?>
<?php unset($__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043)): ?>
<?php $component = $__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043; ?>
<?php unset($__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043); ?>
<?php endif; ?>
        <!-- /.navbar -->
    
        <!-- Main Sidebar Container -->
        <?php if (isset($component)) { $__componentOriginal4d3090547e878a0d007cc9b2331a31b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d3090547e878a0d007cc9b2331a31b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d3090547e878a0d007cc9b2331a31b9)): ?>
<?php $attributes = $__attributesOriginal4d3090547e878a0d007cc9b2331a31b9; ?>
<?php unset($__attributesOriginal4d3090547e878a0d007cc9b2331a31b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d3090547e878a0d007cc9b2331a31b9)): ?>
<?php $component = $__componentOriginal4d3090547e878a0d007cc9b2331a31b9; ?>
<?php unset($__componentOriginal4d3090547e878a0d007cc9b2331a31b9); ?>
<?php endif; ?>
    
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper" style="margin-bottom: 50px">
            <!-- Content Header (Page header) -->
            <?php if (isset($component)) { $__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.content-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0)): ?>
<?php $attributes = $__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0; ?>
<?php unset($__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0)): ?>
<?php $component = $__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0; ?>
<?php unset($__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0); ?>
<?php endif; ?>
            <!-- /.content-header -->
    
            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <!-- Info boxes -->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Daftar Router</h3>
                                    <div class="card-tools">
                                        <?php if(in_array(auth()->user()->role, ['member'])): ?>

                                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                            data-target="#tambahRouterModal">
                                            <i class="fas fa-plus"></i> Tambah Router
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <div class="d-md-flex">
                                        <div class="p-1 flex-fill" style="overflow: hidden">
                                            <div class="table-responsive">
                                                <table id="routerTable" class="table">
                                                    <thead>
                                                        <tr>
                                                            <th style="width: 10px">#</th>
                                                            <th>Status</th>
                                                            <th>Router ID</th>
                                                            <th>Nama Router</th>
                                                            <th>Port API</th>
                                                            <th>Port Winbox</th>
                                                            <th>Username</th>
                                                            <th>Actions</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $mikrotik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $router): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($loop->iteration); ?></td>
                                                                <td>
                                                                    <?php if(isset($routerStatuses[$router->id]) && $routerStatuses[$router->id] == 'Online'): ?>
                                                                        <span class="badge badge-success">Online</span>
                                                                    <?php else: ?>
                                                                        <span class="badge badge-danger">Offline</span>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td><?php echo e($router->router_id); ?></td>
                                                                <td><?php echo e($router->site); ?></td>
                                                                <td><?php echo e("id-1.aqtnetwork.my.id:".$router->port_api); ?></td>
                                                                <td><?php echo e("id-1.aqtnetwork.my.id:".$router->port_winbox); ?></td>
                                                                <td><?php echo e($router->username); ?></td>
                                                                <td>
                                                                    <div class="dropdown">
                                                                        <button class="btn btn-sm btn-primary dropdown-toggle" type="button"
                                                                            id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                                                                            aria-expanded="false">
                                                                            Actions
                                                                        </button>
                                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                                            <!-- Cek Koneksi -->
                                                                            <a class="dropdown-item" href="<?php echo e(route('cek-koneksi', $router->id)); ?>">
                                                                                <i class="fas fa-plug mr-2"></i> Cek Koneksi
                                                                            </a>
                                                                            <!-- Copy Script -->
                                                                            <a class="dropdown-item copy-script" href="#"
                                                                                data-router="<?php echo e($router->id); ?>">
                                                                                <i class="fas fa-copy mr-2"></i> Copy Script
                                                                            </a>
                                                                            <!-- Reset Koneksi -->
                                                                            <a class="dropdown-item" href="#">
                                                                                <i class="fas fa-redo mr-2"></i> Reset Koneksi
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <!-- Router Table -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
    
        <!-- Modal to Add Router -->
        <div class="modal fade" id="tambahRouterModal" tabindex="-1" aria-labelledby="tambahRouterModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="tambahRouterModalLabel">Tambah Router</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="tambahRouterForm" method="post" action="<?php echo e(route('member.router.tambah')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <!-- Nama Router -->
                            <div class="form-group">
                                <label for="namaRouter">Nama Router</label>
                                <input type="text" class="form-control" id="namaRouter" name="site"
                                    placeholder="Masukkan nama router" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    
        <?php if (isset($component)) { $__componentOriginal10a5c05463c515701704e42d3b506416 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal10a5c05463c515701704e42d3b506416 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal10a5c05463c515701704e42d3b506416)): ?>
<?php $attributes = $__attributesOriginal10a5c05463c515701704e42d3b506416; ?>
<?php unset($__attributesOriginal10a5c05463c515701704e42d3b506416); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal10a5c05463c515701704e42d3b506416)): ?>
<?php $component = $__componentOriginal10a5c05463c515701704e42d3b506416; ?>
<?php unset($__componentOriginal10a5c05463c515701704e42d3b506416); ?>
<?php endif; ?>
    </div>
    <!-- ./wrapper -->

    <?php if (isset($component)) { $__componentOriginal4f8732821ff8626b580bba7a0c973801 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f8732821ff8626b580bba7a0c973801 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f8732821ff8626b580bba7a0c973801)): ?>
<?php $attributes = $__attributesOriginal4f8732821ff8626b580bba7a0c973801; ?>
<?php unset($__attributesOriginal4f8732821ff8626b580bba7a0c973801); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f8732821ff8626b580bba7a0c973801)): ?>
<?php $component = $__componentOriginal4f8732821ff8626b580bba7a0c973801; ?>
<?php unset($__componentOriginal4f8732821ff8626b580bba7a0c973801); ?>
<?php endif; ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Ambil semua tombol copy script
            const copyButtons = document.querySelectorAll('.copy-script');

            // Tambahkan event listener pada setiap tombol copy script
            copyButtons.forEach(button => {
                button.addEventListener('click', function () {
                    // Ambil id router yang terkait dengan tombol ini
                    const routerId = this.getAttribute('data-router');

                    // Ambil data router menggunakan AJAX atau data yang sudah ada
                    const routerData = <?php echo json_encode(
                        $mikrotik, 15, 512) ?>; // Menyertakan data router dari server ke dalam JavaScript

                    // Cari data router yang sesuai dengan id
                    const router = routerData.find(r => r.id == routerId);

                    if (router) {
                        const scriptContent =
                            `
/ip service set disable=no port=${router.port_api} [find name=api]; /ip service set disable=no port=${router.port_winbox} [find name=winbox]; /ip firewall nat remove [find comment="Biller_Remod"]; /ip firewall nat add chain=dstnat dst-port=${router.port_remoteweb} protocol=tcp action=dst-nat to-address=0.0.0.0 to-port=80 comment="Biller_Remod"; /interface l2tp-client add name="${router.vpn_name}" comment="VPN Billing" connect-to=id-1.aqtnetwork.my.id user=${router.vpn_username} password=${router.vpn_password} disable=no; /user remove [find group=BILLER]; /user group remove [find name="BILLER"]; /user group add name=BILLER policy=write,read,api,test; /user add name=${router.username} password=${router.password} group=BILLER; /ip pool add name=Isolir ranges=172.16.255.1-172.16.255.254; /ppp profile add name=isolir-biller local-address=172.16.255.1 remote-address=Isolir; /ip firewall filter add chain=forward src-address-list=isolir-pelanggan action=drop comment="Generate By Biller - Isolir"; /system script add name=auto-isolir source=":foreach i in=[/ppp active find where profile=isolir-biller] do={/ip firewall address-list add list=isolir-pelanggan address=[/ppp active get $i address]}"; /system scheduler add name=cek-isolir interval=1m on-event=auto-isolir; :foreach i in=[/ppp active find where profile=isolir-biller] do={ :local user [/ppp active get $i name]; /ppp active remove $i; /ip firewall address-list add list=isolir-pelanggan address=[/ppp secret get [find name=$user] remote-address]; };`;

                        // Buat elemen textarea sementara untuk menyalin script
                        const textarea = document.createElement('textarea');
                        textarea.value = scriptContent;
                        document.body.appendChild(textarea);

                        // Pilih dan salin isi script
                        textarea.select();
                        document.execCommand('copy');

                        // Hapus elemen textarea
                        document.body.removeChild(textarea);

                        // Tampilkan pesan berhasil
                        alert('Script berhasil disalin!');
                    }
                });
            });
        });

    </script>
    <!-- DataTables Initialization -->
<script>
    $(document).ready(function () {
        $('#routerTable').DataTable({
            responsive: true,
            autoWidth: false,
            language: {
                url: "//cdn.datatables.net/plug-ins/1.13.5/i18n/id.json" // Bahasa Indonesia (optional)
            }
        });
    });
</script>

    <?php if (isset($component)) { $__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be)): ?>
<?php $attributes = $__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be; ?>
<?php unset($__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be)): ?>
<?php $component = $__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be; ?>
<?php unset($__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be); ?>
<?php endif; ?>
</body>

</html>
<?php /**PATH /home/lun4t1c/PROJECT/BILLER/resources/views/ROLE/MEMBER/ROUTER/router.blade.php ENDPATH**/ ?>