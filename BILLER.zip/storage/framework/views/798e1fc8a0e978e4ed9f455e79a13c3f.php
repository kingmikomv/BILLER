<?php if (isset($component)) { $__componentOriginale74a36bbe4c110c757bc794195f1a772 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale74a36bbe4c110c757bc794195f1a772 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale74a36bbe4c110c757bc794195f1a772)): ?>
<?php $attributes = $__attributesOriginale74a36bbe4c110c757bc794195f1a772; ?>
<?php unset($__attributesOriginale74a36bbe4c110c757bc794195f1a772); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale74a36bbe4c110c757bc794195f1a772)): ?>
<?php $component = $__componentOriginale74a36bbe4c110c757bc794195f1a772; ?>
<?php unset($__componentOriginale74a36bbe4c110c757bc794195f1a772); ?>
<?php endif; ?>

<body class="hold-transition dark-mode sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
    <div class="wrapper">

        <?php if (isset($component)) { $__componentOriginal5b1fda1569546060c763c3acc6e2c0f0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.preload','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.preload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0)): ?>
<?php $attributes = $__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0; ?>
<?php unset($__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b1fda1569546060c763c3acc6e2c0f0)): ?>
<?php $component = $__componentOriginal5b1fda1569546060c763c3acc6e2c0f0; ?>
<?php unset($__componentOriginal5b1fda1569546060c763c3acc6e2c0f0); ?>
<?php endif; ?>

        <!-- Navbar -->
        <?php if (isset($component)) { $__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043)): ?>
<?php $attributes = $__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043; ?>
<?php unset($__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043)): ?>
<?php $component = $__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043; ?>
<?php unset($__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043); ?>
<?php endif; ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php if (isset($component)) { $__componentOriginal4d3090547e878a0d007cc9b2331a31b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d3090547e878a0d007cc9b2331a31b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d3090547e878a0d007cc9b2331a31b9)): ?>
<?php $attributes = $__attributesOriginal4d3090547e878a0d007cc9b2331a31b9; ?>
<?php unset($__attributesOriginal4d3090547e878a0d007cc9b2331a31b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d3090547e878a0d007cc9b2331a31b9)): ?>
<?php $component = $__componentOriginal4d3090547e878a0d007cc9b2331a31b9; ?>
<?php unset($__componentOriginal4d3090547e878a0d007cc9b2331a31b9); ?>
<?php endif; ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper" style="margin-bottom: 50px">
            <!-- Content Header (Page header) -->
            <?php if (isset($component)) { $__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.content-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0)): ?>
<?php $attributes = $__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0; ?>
<?php unset($__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0)): ?>
<?php $component = $__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0; ?>
<?php unset($__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0); ?>
<?php endif; ?>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <!-- Info boxes -->


                    <div class="row">

                        <div class="col-md-12">



                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Pekerja</h3>

                                    <div class="card-tools">
                                        <!-- Tombol untuk membuka modal -->
                                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                            data-target="#modalTambahPekerja">
                                            <i class="fas fa-plus"></i> Tambah Pekerja
                                        </button>


                                    </div>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body table-responsive">
                                    <table class="table" id="tablePekerja">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Pekerja</th>
                                                <th>Username</th>
                                                <th>Email</th>
                                                <th>Posisi</th>
                                                <th>No Telepon</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $pekerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key + 1); ?></td>
                                                <td><?php echo e($item->name); ?></td>
                                                <td><?php echo e($item->username); ?></td>
                                                <td><?php echo e($item->email); ?></td>
                                                <td><?php echo e($item->role); ?></td>
                                                <td><?php echo e($item->phone); ?></td>
                                                <td>
                                                    <a href=""
                                                        class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> Edit</a>
                                                    <a href=""
                                                        class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.card-body -->
                            </div>






                        </div>


                    </div>


                </div>

            </section>
            <!-- /.content -->
        </div>
        <!-- Modal Tambah Pekerja -->
        <div class="modal fade" id="modalTambahPekerja" tabindex="-1" role="dialog"
            aria-labelledby="modalTambahPekerjaLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalTambahPekerjaLabel">Tambah Pekerja</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="formTambahPekerja" method="POST" action="<?php echo e(route('addPekerja')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">

                            <div class="form-group">
                                <label for="namaPekerja">Nama Pekerja</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['namaPekerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="namaPekerja" name="namaPekerja" placeholder="Masukkan nama pekerja"
                                    value="<?php echo e(old('namaPekerja')); ?>" required>
                                <?php $__errorArgs = ['namaPekerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="usernamePekerja">Username</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['usernamePekerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="usernamePekerja" name="usernamePekerja" placeholder="Masukkan username pekerja"
                                    value="<?php echo e(old('usernamePekerja')); ?>" required>
                                <?php $__errorArgs = ['usernamePekerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="emailPekerja">Email Login</label>
                                <input type="email" class="form-control <?php $__errorArgs = ['emailPekerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="emailPekerja" name="emailPekerja" placeholder="Masukkan email pekerja"
                                    value="<?php echo e(old('emailPekerja')); ?>" required>
                                <?php $__errorArgs = ['emailPekerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="passwordPekerja">Password Login</label>
                                <input type="password"
                                    class="form-control <?php $__errorArgs = ['passwordPekerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="passwordPekerja" name="passwordPekerja" placeholder="Masukkan password pekerja"
                                    required>
                                <?php $__errorArgs = ['passwordPekerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="passwordPekerja_confirmation">Konfirmasi Password</label>
                                <input type="password" class="form-control" id="passwordPekerja_confirmation"
                                    name="passwordPekerja_confirmation" placeholder="Konfirmasi password pekerja"
                                    required>
                            </div>

                            <div class="form-group">
                                <label for="posisiPekerja">Posisi</label>
                                <select name="posisiPekerja"
                                    class="form-control <?php $__errorArgs = ['posisiPekerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option disabled selected value>Pilih Posisi</option>
                                    <option value="teknisi">Teknisi</option>
                                    <option value="cs">Customer Service</option>
                                    <option value="penagih">Penagih</option>
                                </select>
                                <?php $__errorArgs = ['posisiPekerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="noTeleponPekerja">Nomor Telepon</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['noTeleponPekerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="noTeleponPekerja" name="noTeleponPekerja"
                                    placeholder="Masukkan nomor telepon pekerja" value="<?php echo e(old('noTeleponPekerja')); ?>"
                                    required>
                                <?php $__errorArgs = ['noTeleponPekerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
        <?php if (isset($component)) { $__componentOriginal10a5c05463c515701704e42d3b506416 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal10a5c05463c515701704e42d3b506416 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal10a5c05463c515701704e42d3b506416)): ?>
<?php $attributes = $__attributesOriginal10a5c05463c515701704e42d3b506416; ?>
<?php unset($__attributesOriginal10a5c05463c515701704e42d3b506416); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal10a5c05463c515701704e42d3b506416)): ?>
<?php $component = $__componentOriginal10a5c05463c515701704e42d3b506416; ?>
<?php unset($__componentOriginal10a5c05463c515701704e42d3b506416); ?>
<?php endif; ?>
    </div>
    <!-- ./wrapper -->

    <?php if (isset($component)) { $__componentOriginal4f8732821ff8626b580bba7a0c973801 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f8732821ff8626b580bba7a0c973801 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f8732821ff8626b580bba7a0c973801)): ?>
<?php $attributes = $__attributesOriginal4f8732821ff8626b580bba7a0c973801; ?>
<?php unset($__attributesOriginal4f8732821ff8626b580bba7a0c973801); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f8732821ff8626b580bba7a0c973801)): ?>
<?php $component = $__componentOriginal4f8732821ff8626b580bba7a0c973801; ?>
<?php unset($__componentOriginal4f8732821ff8626b580bba7a0c973801); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be)): ?>
<?php $attributes = $__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be; ?>
<?php unset($__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be)): ?>
<?php $component = $__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be; ?>
<?php unset($__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be); ?>
<?php endif; ?>
    <script>
        $(document).ready(function () {
            $('#tablePekerja').DataTable();
        });

    </script>
</body>

</html>
<?php /**PATH /home/lun4t1c/PROJECT/BILLER/resources/views/ROLE/MEMBER/PEKERJA/index.blade.php ENDPATH**/ ?>