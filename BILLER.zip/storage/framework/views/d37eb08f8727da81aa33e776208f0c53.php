<?php if (isset($component)) { $__componentOriginale74a36bbe4c110c757bc794195f1a772 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale74a36bbe4c110c757bc794195f1a772 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale74a36bbe4c110c757bc794195f1a772)): ?>
<?php $attributes = $__attributesOriginale74a36bbe4c110c757bc794195f1a772; ?>
<?php unset($__attributesOriginale74a36bbe4c110c757bc794195f1a772); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale74a36bbe4c110c757bc794195f1a772)): ?>
<?php $component = $__componentOriginale74a36bbe4c110c757bc794195f1a772; ?>
<?php unset($__componentOriginale74a36bbe4c110c757bc794195f1a772); ?>
<?php endif; ?>

<body class="hold-transition dark-mode sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
    <div class="wrapper">

        <?php if (isset($component)) { $__componentOriginal5b1fda1569546060c763c3acc6e2c0f0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.preload','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.preload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0)): ?>
<?php $attributes = $__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0; ?>
<?php unset($__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b1fda1569546060c763c3acc6e2c0f0)): ?>
<?php $component = $__componentOriginal5b1fda1569546060c763c3acc6e2c0f0; ?>
<?php unset($__componentOriginal5b1fda1569546060c763c3acc6e2c0f0); ?>
<?php endif; ?>

        <!-- Navbar -->
        <?php if (isset($component)) { $__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043)): ?>
<?php $attributes = $__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043; ?>
<?php unset($__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043)): ?>
<?php $component = $__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043; ?>
<?php unset($__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043); ?>
<?php endif; ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php if (isset($component)) { $__componentOriginal4d3090547e878a0d007cc9b2331a31b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d3090547e878a0d007cc9b2331a31b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d3090547e878a0d007cc9b2331a31b9)): ?>
<?php $attributes = $__attributesOriginal4d3090547e878a0d007cc9b2331a31b9; ?>
<?php unset($__attributesOriginal4d3090547e878a0d007cc9b2331a31b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d3090547e878a0d007cc9b2331a31b9)): ?>
<?php $component = $__componentOriginal4d3090547e878a0d007cc9b2331a31b9; ?>
<?php unset($__componentOriginal4d3090547e878a0d007cc9b2331a31b9); ?>
<?php endif; ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper" style="margin-bottom: 50px">
            <!-- Content Header (Page header) -->
            <?php if (isset($component)) { $__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.content-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0)): ?>
<?php $attributes = $__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0; ?>
<?php unset($__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0)): ?>
<?php $component = $__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0; ?>
<?php unset($__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0); ?>
<?php endif; ?>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <!-- Info boxes -->
                    <?php if (isset($component)) { $__componentOriginal3c1a4313cc9d7b89e1d1d46b898558f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1a4313cc9d7b89e1d1d46b898558f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.info-box','data' => ['totalPelanggan' => $totalPelanggan,'totalPelangganAktif' => $totalPelangganAktif,'totalOnline' => $totalOnline,'totalOffline' => $totalOffline,'totalIsolir' => $totalIsolir,'totalRouter' => $totalRouter]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['totalPelanggan' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalPelanggan),'totalPelangganAktif' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalPelangganAktif),'totalOnline' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalOnline),'totalOffline' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalOffline),'totalIsolir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalIsolir),'totalRouter' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalRouter)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1a4313cc9d7b89e1d1d46b898558f2)): ?>
<?php $attributes = $__attributesOriginal3c1a4313cc9d7b89e1d1d46b898558f2; ?>
<?php unset($__attributesOriginal3c1a4313cc9d7b89e1d1d46b898558f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1a4313cc9d7b89e1d1d46b898558f2)): ?>
<?php $component = $__componentOriginal3c1a4313cc9d7b89e1d1d46b898558f2; ?>
<?php unset($__componentOriginal3c1a4313cc9d7b89e1d1d46b898558f2); ?>
<?php endif; ?>

                    <div class="row">

                        <div class="col-md-12">

                            <div class="card">
                                <div class="card-header border-transparent">
                                    <h3 class="card-title">Riwayat Pemasangan Baru</h3>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body table-responsive">
                                    <table class="table" id="tabelRiwayat">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>No Tiket</th>
                                                <th>Nama Pelanggan</th>
                                                <th>Tgl. Ingin Dipasang</th>
                                                <th>Tgl. Terpasang</th>
                                                <th>Dipasang Oleh</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $riwayatPemasangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($riwayat->no_tiket); ?></td>
                                                <td><?php echo e($riwayat->nama_pelanggan); ?></td>
                                                <td><?php echo e($riwayat->tanggal_ingin_pasang); ?></td>
                                                <td><?php echo e($riwayat->tanggal_terpasang); ?></td>
                                                <td><?php echo e($riwayat->dipasang_oleh); ?></td>
                                                <td>
                                                    <button class="btn btn-info btn-sm btnDetail"
                                                        data-tiket="<?php echo e($riwayat->no_tiket); ?>">
                                                        Cek Detail
                                                    </button>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.card-body -->

                                <!-- /.card-footer -->
                            </div>


                        </div>


                    </div>


                </div>

            </section>
            <!-- /.content -->
        </div>
        <div class="modal fade" id="modalDetail" tabindex="-1" role="dialog" aria-labelledby="modalDetailLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalDetailLabel">Detail Pemasangan</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <tbody>
                                    <tr>
                                        <th>No Tiket</th>
                                        <td id="detailTiket"></td>
                                    </tr>
                                    <tr>
                                        <th>Nama Pelanggan</th>
                                        <td id="detailNama"></td>
                                    </tr>
                                    <tr>
                                        <th>Tanggal Ingin Dipasang</th>
                                        <td id="detailTgl"></td>
                                    </tr>
                                    <tr>
                                        <th>Tanggal Terpasang</th>
                                        <td id="detailTglTerpasang"></td>
                                    </tr>
                                    <tr>
                                        <th>Dipasang Oleh</th>
                                        <td id="detailDipasang"></td>
                                    </tr>
                                    <tr>
                                        <th>Akun PPPoE</th>
                                        <td id="detailAkun"></td>
                                    </tr>
                                    <tr>
                                        <th>Password PPPoE</th>
                                        <td id="detailPass"></td>
                                    </tr>
                                    <tr>
                                        <th>Nama WiFi</th>
                                        <td id="detailSsid"></td>
                                    </tr>
                                    <tr>
                                        <th>Password WiFi</th>
                                        <td id="detailWifiPass"></td>
                                    </tr>
                                    <tr>
                                        <th>Alamat</th>
                                        <td class="text-wrap" style="max-width: 400px; word-break: break-word;">
                                            <span id="detailAlamat"></span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <?php if (isset($component)) { $__componentOriginal10a5c05463c515701704e42d3b506416 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal10a5c05463c515701704e42d3b506416 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal10a5c05463c515701704e42d3b506416)): ?>
<?php $attributes = $__attributesOriginal10a5c05463c515701704e42d3b506416; ?>
<?php unset($__attributesOriginal10a5c05463c515701704e42d3b506416); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal10a5c05463c515701704e42d3b506416)): ?>
<?php $component = $__componentOriginal10a5c05463c515701704e42d3b506416; ?>
<?php unset($__componentOriginal10a5c05463c515701704e42d3b506416); ?>
<?php endif; ?>
    </div>
    <!-- ./wrapper -->

    <?php if (isset($component)) { $__componentOriginal4f8732821ff8626b580bba7a0c973801 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f8732821ff8626b580bba7a0c973801 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f8732821ff8626b580bba7a0c973801)): ?>
<?php $attributes = $__attributesOriginal4f8732821ff8626b580bba7a0c973801; ?>
<?php unset($__attributesOriginal4f8732821ff8626b580bba7a0c973801); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f8732821ff8626b580bba7a0c973801)): ?>
<?php $component = $__componentOriginal4f8732821ff8626b580bba7a0c973801; ?>
<?php unset($__componentOriginal4f8732821ff8626b580bba7a0c973801); ?>
<?php endif; ?>
    <script>
        $(document).ready(function () {
            $('#tabelRiwayat').DataTable(); // Aktifkan DataTables


        });
        $(document).ready(function () {
            $('#tabelRiwayat').DataTable(); // Aktifkan DataTables

            $('.btnDetail').on('click', function () {
                var tiket = $(this).data('tiket'); // Ambil nomor tiket dari tombol
                var url = "<?php echo e(route('riwayat.pemasangan', ':tiket')); ?>".replace(':tiket',
                    tiket); // Buat URL sesuai route

                $.ajax({
                    url: url, // Gunakan route Laravel
                    type: 'GET',
                    success: function (data) {
                        if (data.success) {
                            $('#detailTiket').text(data.riwayat.no_tiket);
                            $('#detailNama').text(data.riwayat.nama_pelanggan);
                            $('#detailTgl').text(data.riwayat.tanggal_ingin_pasang);
                            $('#detailTglTerpasang').text(data.riwayat.tanggal_terpasang);
                            $('#detailDipasang').text(data.riwayat.dipasang_oleh);
                            $('#detailAkun').text(data.riwayat.akun_pppoe);
                            $('#detailPass').text(data.riwayat.password_pppoe);
                            $('#detailSsid').text(data.riwayat.nama_ssid);
                            $('#detailWifiPass').text(data.riwayat.password_ssid);
                            $('#detailAlamat').text(data.riwayat.alamat);
                            $('#modalDetail').modal('show'); // Tampilkan modal
                        } else {
                            alert('Data tidak ditemukan!');
                        }
                    }
                });
            });
        });

    </script>
</body>

</html>
<?php /**PATH /home/lun4t1c/PROJECT/BILLER/resources/views/ROLE/MEMBER/index.blade.php ENDPATH**/ ?>