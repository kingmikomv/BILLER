<?php if (isset($component)) { $__componentOriginala1635358133f374215876f4b24de7544 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala1635358133f374215876f4b24de7544 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.login.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('login.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala1635358133f374215876f4b24de7544)): ?>
<?php $attributes = $__attributesOriginala1635358133f374215876f4b24de7544; ?>
<?php unset($__attributesOriginala1635358133f374215876f4b24de7544); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1635358133f374215876f4b24de7544)): ?>
<?php $component = $__componentOriginala1635358133f374215876f4b24de7544; ?>
<?php unset($__componentOriginala1635358133f374215876f4b24de7544); ?>
<?php endif; ?>

 <div class="login-box">
   <!-- /.login-logo -->
   <div class="card card-outline card-primary">
     <div class="card-header text-center">
       <a href="<?php echo e(url('/login')); ?>" class="h1">
        <img src="<?php echo e(asset('assetlogin/re.png')); ?>" alt="BILLER Logo" class="img-fluid" style="max-height: 130px;">

      </a>
     </div>
     <div class="card-body">
       <p class="login-box-msg">Login Disini</p>
 
       <form method="POST" action="<?php echo e(route('login')); ?>">
         <?php echo csrf_field(); ?>
 
         <div class="input-group mb-3">
          <input 
              type="text" 
              class="form-control <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
              placeholder="Email atau Username" 
              value="<?php echo e(old('login')); ?>" 
              name="login" 
              autocomplete="username" 
              autofocus
          >
          <div class="input-group-append">
              <div class="input-group-text">
                  <span class="fas fa-user"></span>
              </div>
          </div>
          <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="alert alert-danger mt-2">
                  <strong><?php echo e($message); ?></strong>
              </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      
 
         <div class="input-group mb-3">
           <input 
             type="password" 
             class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
             placeholder="Password" 
             name="password" 
             required 
             autocomplete="current-password"
           >
           <div class="input-group-append">
             <div class="input-group-text">
               <span class="fas fa-lock"></span>
             </div>
           </div>
           <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
             <div class="alert alert-danger mt-2">
               <strong><?php echo e($message); ?></strong>
             </div>
           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
         </div>
 
         <div class="row">
           <div class="col-8">
             <div class="icheck-primary">
               <input 
                 type="checkbox" 
                 name="remember" 
                 id="remember" 
                 <?php echo e(old('remember') ? 'checked' : ''); ?>

               >
               <label for="remember">
                 Ingat Saya
               </label>
             </div>
           </div>
           <!-- /.col -->
           <div class="col-4">
             <button type="submit" class="btn btn-primary btn-block">Login</button>
           </div>
           <!-- /.col -->
         </div>
       </form>
 
       <p class="mb-1">
         <?php if(Route::has('password.request')): ?>
           <a href="<?php echo e(route('password.request')); ?>">Lupa Password</a>
         <?php endif; ?>
       </p>
       <p class="mb-0">
         <a href="<?php echo e(route('register')); ?>" class="text-center">Belum Punya Akun ? Daftar Member</a>
       </p>
     </div>
     <!-- /.card-body -->
   </div>
   <!-- /.card -->
 </div>
 <!-- /.login-box -->
 
 <?php if (isset($component)) { $__componentOriginalf6de55dad310adad0f44efac51b1af4c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf6de55dad310adad0f44efac51b1af4c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.login.script','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('login.script'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf6de55dad310adad0f44efac51b1af4c)): ?>
<?php $attributes = $__attributesOriginalf6de55dad310adad0f44efac51b1af4c; ?>
<?php unset($__attributesOriginalf6de55dad310adad0f44efac51b1af4c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf6de55dad310adad0f44efac51b1af4c)): ?>
<?php $component = $__componentOriginalf6de55dad310adad0f44efac51b1af4c; ?>
<?php unset($__componentOriginalf6de55dad310adad0f44efac51b1af4c); ?>
<?php endif; ?>
 <?php /**PATH /home/lun4t1c/PROJECT/BILLER/resources/views/auth/login.blade.php ENDPATH**/ ?>