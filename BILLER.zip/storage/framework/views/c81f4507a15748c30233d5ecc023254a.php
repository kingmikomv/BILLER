<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

<?php if (isset($component)) { $__componentOriginale74a36bbe4c110c757bc794195f1a772 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale74a36bbe4c110c757bc794195f1a772 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale74a36bbe4c110c757bc794195f1a772)): ?>
<?php $attributes = $__attributesOriginale74a36bbe4c110c757bc794195f1a772; ?>
<?php unset($__attributesOriginale74a36bbe4c110c757bc794195f1a772); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale74a36bbe4c110c757bc794195f1a772)): ?>
<?php $component = $__componentOriginale74a36bbe4c110c757bc794195f1a772; ?>
<?php unset($__componentOriginale74a36bbe4c110c757bc794195f1a772); ?>
<?php endif; ?>

<body class="hold-transition dark-mode sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
    <div class="wrapper">
        <?php if (isset($component)) { $__componentOriginal5b1fda1569546060c763c3acc6e2c0f0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.preload','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.preload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0)): ?>
<?php $attributes = $__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0; ?>
<?php unset($__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b1fda1569546060c763c3acc6e2c0f0)): ?>
<?php $component = $__componentOriginal5b1fda1569546060c763c3acc6e2c0f0; ?>
<?php unset($__componentOriginal5b1fda1569546060c763c3acc6e2c0f0); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043)): ?>
<?php $attributes = $__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043; ?>
<?php unset($__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043)): ?>
<?php $component = $__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043; ?>
<?php unset($__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal4d3090547e878a0d007cc9b2331a31b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d3090547e878a0d007cc9b2331a31b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d3090547e878a0d007cc9b2331a31b9)): ?>
<?php $attributes = $__attributesOriginal4d3090547e878a0d007cc9b2331a31b9; ?>
<?php unset($__attributesOriginal4d3090547e878a0d007cc9b2331a31b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d3090547e878a0d007cc9b2331a31b9)): ?>
<?php $component = $__componentOriginal4d3090547e878a0d007cc9b2331a31b9; ?>
<?php unset($__componentOriginal4d3090547e878a0d007cc9b2331a31b9); ?>
<?php endif; ?>

        <div class="content-wrapper" style="margin-bottom: 50px">
            <?php if (isset($component)) { $__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.content-header','data' => ['title' => 'Data Pelanggan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Data Pelanggan']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0)): ?>
<?php $attributes = $__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0; ?>
<?php unset($__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0)): ?>
<?php $component = $__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0; ?>
<?php unset($__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0); ?>
<?php endif; ?>

            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Data Pelanggan</h3>
                                    <div class="card-tools">
                                        <a href="<?php echo e(route('pelanggan')); ?>" class="btn btn-sm btn-secondary"><i
                                                class="fas fa-arrow-left"></i> Kembali</a>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Nama Pelanggan</th>
                                            <td><?php echo e($pelanggan->nama_pelanggan); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Alamat</th>
                                            <td><?php echo e($pelanggan->alamat); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Paket</th>
                                            <td><?php echo e($pelanggan->paket->nama_paket); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Akun PPPoE</th>
                                            <td><?php echo e($pelanggan->akun_pppoe); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Traffic Data Up / Down</th>
                                            <td id="traffic-combined">Memuat...</td>
                                        </tr>
                                        <tr>
                                            <th>Waktu Aktif</th>
                                            <td><?php echo e($formattedUptime); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Total BW Up / Down</th>
                                            <td id="total-bw-upload-download">Memuat...</td>
                                        </tr>
                                        <tr>
                                            <th>Cek Ping</th>
                                            <td>
                                                <a href="javascript:void(0);" class="btn btn-primary"
                                                    onclick="cekPing('<?php echo e($pelanggan->akun_pppoe); ?>')">Cek Ping !</a>
                                            </td>
                                        </tr>
                                    </table>

                                    <h4 class="mt-4">Traffic Monitoring</h4>
                                    <div class="row">
                                        <div class="col-md-12 mb-5">
                                            <div id="traffic-chart"></div>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
        </div>
        <?php if (isset($component)) { $__componentOriginal10a5c05463c515701704e42d3b506416 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal10a5c05463c515701704e42d3b506416 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.footer','data' => ['style' => 'margin-top 50px']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'margin-top 50px']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal10a5c05463c515701704e42d3b506416)): ?>
<?php $attributes = $__attributesOriginal10a5c05463c515701704e42d3b506416; ?>
<?php unset($__attributesOriginal10a5c05463c515701704e42d3b506416); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal10a5c05463c515701704e42d3b506416)): ?>
<?php $component = $__componentOriginal10a5c05463c515701704e42d3b506416; ?>
<?php unset($__componentOriginal10a5c05463c515701704e42d3b506416); ?>
<?php endif; ?>

    </div>

    <?php if (isset($component)) { $__componentOriginal4f8732821ff8626b580bba7a0c973801 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f8732821ff8626b580bba7a0c973801 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f8732821ff8626b580bba7a0c973801)): ?>
<?php $attributes = $__attributesOriginal4f8732821ff8626b580bba7a0c973801; ?>
<?php unset($__attributesOriginal4f8732821ff8626b580bba7a0c973801); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f8732821ff8626b580bba7a0c973801)): ?>
<?php $component = $__componentOriginal4f8732821ff8626b580bba7a0c973801; ?>
<?php unset($__componentOriginal4f8732821ff8626b580bba7a0c973801); ?>
<?php endif; ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const routerId = "<?php echo e($pelanggan->router_id); ?>";
            const akunPppoe = "<?php echo e($pelanggan->akun_pppoe); ?>";
            const apiUrl =
                `<?php echo e(route('traffic.data', ['id' => $pelanggan->id])); ?>?router_id=${routerId}&akun_pppoe=${akunPppoe}`;

            let downloadData = [];
            let uploadData = [];

            const chartOptions = {
                chart: {
                    type: 'line',
                    height: 300,
                    animations: {
                        enabled: true,
                        easing: 'easeinout',
                        dynamicAnimation: {
                            speed: 800
                        }
                    },
                    background: '#ffffff',
                    toolbar: {
                        show: false
                    }
                },
                series: [{
                        name: "DOWNLOAD",
                        data: downloadData
                    },
                    {
                        name: "UPLOAD",
                        data: uploadData
                    }
                ],
                xaxis: {
                    type: 'datetime',
                    labels: {
                        datetimeUTC: false
                    },
                    title: {
                        text: "Waktu",
                        style: {
                            color: '#000',
                            fontSize: '12px'
                        }
                    }
                },
                yaxis: {
                    labels: {
                        formatter: function (value) {
                            return formatSpeed(value);
                        }
                    },
                    title: {
                        text: "Traffic",
                        style: {
                            color: '#000',
                            fontSize: '12px'
                        }
                    },
                    min: 0,
                    tickAmount: 6
                },
                colors: ['#FF4560', '#00E396'],
                stroke: {
                    curve: 'smooth',
                    width: 2
                },
                markers: {
                    size: 0,
                    colors: ['#FF4560', '#00E396'],
                    strokeColors: '#fff',
                    strokeWidth: 2,
                    hover: {
                        size: 8
                    }
                },
                legend: {
                    position: 'bottom',
                    markers: {
                        width: 14,
                        height: 14,
                        radius: 7
                    }
                },
                tooltip: {
                    shared: true,
                    intersect: false,
                    x: {
                        format: 'HH:mm:ss'
                    },
                    y: {
                        formatter: function (value) {
                            return formatSpeed(value);
                        }
                    }
                },
                noData: {
                    text: 'Memuat data...',
                    align: 'center',
                    verticalAlign: 'middle',
                    style: {
                        fontSize: '14px'
                    }
                }
            };

            const chart = new ApexCharts(document.querySelector('#traffic-chart'), chartOptions);
            chart.render();

            async function fetchTrafficData() {
                try {
                    const response = await fetch(apiUrl);
                    const data = await response.json();

                    if (data.error) {
                        console.error(data.error);
                        return;
                    }

                    const txInBps = data.rx; // Download
                    const rxInBps = data.tx; // Upload
                    const timestamp = new Date().getTime();

                    if (txInBps >= 0 && rxInBps >= 0) {
                        downloadData.push({
                            x: timestamp,
                            y: rxInBps
                        });
                        uploadData.push({
                            x: timestamp,
                            y: txInBps
                        });
                    }

                    if (downloadData.length > 50) downloadData.shift();
                    if (uploadData.length > 50) uploadData.shift();

                    chart.updateSeries([{
                            name: "DOWNLOAD",
                            data: downloadData
                        },
                        {
                            name: "UPLOAD",
                            data: uploadData
                        }
                    ]);

                    // Update tabel untuk upload/download
                    document.getElementById('traffic-combined').textContent =
                        `${formatSpeed(rxInBps)} / ${formatSpeed(txInBps)}`;
                } catch (error) {
                    console.error("Gagal mengambil data:", error);
                }
            }

            function formatSpeed(value) {
                if (value >= 1e9) {
                    return (value / 1e9).toFixed(2) + " Gbps";
                } else if (value >= 1e6) {
                    return (value / 1e6).toFixed(2) + " Mbps";
                } else if (value >= 1e3) {
                    return (value / 1e3).toFixed(2) + " Kbps";
                } else {
                    return value.toFixed(2) + " bps";
                }
            }

            setInterval(fetchTrafficData, 1000);
        });

    </script>
    <script>
        function updateBandwidth() {
            const pelangganId = "<?php echo e($pelanggan->id); ?>"; // ID Pelanggan

            $.ajax({
                url: "<?php echo e(route('getBandwidth', ':id')); ?>".replace(':id',
                    pelangganId), // Mengganti :id dengan pelangganId
                method: 'GET',
                success: function (response) {
                    // Update Total Bandwidth
                    $('#total-bw-upload-download').text(`${response.totTx} / ${response.totRx}`);
                },
                error: function (error) {
                    console.log("Gagal mengambil data bandwidth:", error);
                    $('#total-bw-upload-download').text('Gagal memuat data');
                }
            });
        }

        // Update setiap 2 detik
        setInterval(updateBandwidth, 2000);

    </script>
    <script>
        const akunPppoe = "<?php echo e($pelanggan->akun_pppoe); ?>";

        // Fungsi untuk mengecek ping
        function cekPing(akunPppoe) {
            Swal.fire({
                title: 'Sedang melakukan Cek Ping...',
                text: 'Mohon tunggu sebentar...',
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading();
                },
                customClass: {
                    popup: 'swal-popup-small'
                }
            });

            $.ajax({
                url: `<?php echo e(route('cekPing', ['akun' => '__akun_pppoe__'])); ?>`.replace('__akun_pppoe__',
                    akunPppoe),
                method: 'GET',
                success: function (response) {
                    Swal.close(); // Menutup loading indicator

                    if (response.success) {
                        // Tampilkan hasil ping
                        let pingResults = response.pingResults;
                        let ipAddress = response.ip; // Ambil IP address dari response

                        // Fungsi untuk format waktu (jam:menit:detik)
                        function formatTime(date) {
                            let hours = date.getHours().toString().padStart(2, '0');
                            let minutes = date.getMinutes().toString().padStart(2, '0');
                            let seconds = date.getSeconds().toString().padStart(2, '0');
                            return `${hours}:${minutes}:${seconds}`;
                        }

                        // Membuat HTML untuk hasil ping dengan tabel
                        let pingText =
                            '<table style="width:100%; text-align: center; border-collapse: collapse; table-border: 1px;">';
                        pingText +=
                        '<tr><th>Test </th><th>Waktu</th><th>Hasil</th></tr>'; // Menambahkan header tabel
                        pingResults.forEach(function (result, index) {
                            // Mendapatkan waktu saat ping dilakukan
                            let pingTime = formatTime(new Date());

                            // Cek apakah hasil ping adalah timeout
                            if (result.includes("Timeout")) {
                                pingText +=
                                    `<tr><td>Tes ${index + 1}</td><td>${pingTime}</td><td style="color: red;">Timeout</td></tr>`;
                            } else {
                                pingText +=
                                    `<tr><td>Tes ${index + 1}</td><td>${pingTime}</td><td style="color: green;">${result}</td></tr>`;
                            }
                        });
                        pingText += '</table>';

                        Swal.fire({
                            title: `Hasil Ping Ke Ip  ${ipAddress}`, // Menampilkan IP address di title
                            html: pingText, // Menampilkan hasil ping dalam format HTML
                            icon: 'info',
                            showConfirmButton: true,
                            customClass: {
                                popup: 'swal-popup-small'
                            }
                        });
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: 'Terjadi kesalahan saat melakukan ping.',
                            icon: 'error',
                            showConfirmButton: true,
                            customClass: {
                                popup: 'swal-popup-small'
                            }
                        });
                    }
                },
                error: function (error) {
                    Swal.close();
                    Swal.fire({
                        title: 'Error',
                        text: 'Tidak dapat menghubungi server untuk melakukan ping.',
                        icon: 'error',
                        showConfirmButton: true,
                        customClass: {
                            popup: 'swal-popup-small'
                        }
                    });
                }
            });
        }

        // Panggil fungsi cekPing saat tombol diklik
        $(document).ready(function () {
            $("a[data-action='cekPing']").on('click', function () {
                cekPing(akunPppoe);
            });
        });

    </script>



</body>

</html>
<?php /**PATH /home/lun4t1c/PROJECT/BILLER/resources/views/ROLE/MEMBER/PELANGGAN/data.blade.php ENDPATH**/ ?>