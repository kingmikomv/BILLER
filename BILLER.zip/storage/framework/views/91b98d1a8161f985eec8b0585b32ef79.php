<?php echo e($slot); ?>

<?php /**PATH /home/lun4t1c/PROJECT/BILLER/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>