<?php if(session('success')): ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Success',
        text: "<?php echo session('success'); ?>",
        confirmButtonText: 'OK'
    });
</script>
<?php endif; ?>

<?php if(session('error')): ?>
<script>
    Swal.fire({
        icon: 'error',
        title: 'Error',
        text: "<?php echo e(session('error')); ?>",
        confirmButtonText: 'Coba Lagi'
    });
</script>
<?php endif; ?>
<?php /**PATH /home/lun4t1c/PROJECT/BILLER/resources/views/components/dhs/alert.blade.php ENDPATH**/ ?>