<?php if (isset($component)) { $__componentOriginale74a36bbe4c110c757bc794195f1a772 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale74a36bbe4c110c757bc794195f1a772 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale74a36bbe4c110c757bc794195f1a772)): ?>
<?php $attributes = $__attributesOriginale74a36bbe4c110c757bc794195f1a772; ?>
<?php unset($__attributesOriginale74a36bbe4c110c757bc794195f1a772); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale74a36bbe4c110c757bc794195f1a772)): ?>
<?php $component = $__componentOriginale74a36bbe4c110c757bc794195f1a772; ?>
<?php unset($__componentOriginale74a36bbe4c110c757bc794195f1a772); ?>
<?php endif; ?>

<body class="hold-transition dark-mode sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
    <div class="wrapper">

        <?php if (isset($component)) { $__componentOriginal5b1fda1569546060c763c3acc6e2c0f0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.preload','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.preload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0)): ?>
<?php $attributes = $__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0; ?>
<?php unset($__attributesOriginal5b1fda1569546060c763c3acc6e2c0f0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b1fda1569546060c763c3acc6e2c0f0)): ?>
<?php $component = $__componentOriginal5b1fda1569546060c763c3acc6e2c0f0; ?>
<?php unset($__componentOriginal5b1fda1569546060c763c3acc6e2c0f0); ?>
<?php endif; ?>

        <!-- Navbar -->
        <?php if (isset($component)) { $__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043)): ?>
<?php $attributes = $__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043; ?>
<?php unset($__attributesOriginaldb59ef1c5d84e22dc8a1a089d88df043); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043)): ?>
<?php $component = $__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043; ?>
<?php unset($__componentOriginaldb59ef1c5d84e22dc8a1a089d88df043); ?>
<?php endif; ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php if (isset($component)) { $__componentOriginal4d3090547e878a0d007cc9b2331a31b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d3090547e878a0d007cc9b2331a31b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d3090547e878a0d007cc9b2331a31b9)): ?>
<?php $attributes = $__attributesOriginal4d3090547e878a0d007cc9b2331a31b9; ?>
<?php unset($__attributesOriginal4d3090547e878a0d007cc9b2331a31b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d3090547e878a0d007cc9b2331a31b9)): ?>
<?php $component = $__componentOriginal4d3090547e878a0d007cc9b2331a31b9; ?>
<?php unset($__componentOriginal4d3090547e878a0d007cc9b2331a31b9); ?>
<?php endif; ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper" style="margin-bottom: 50px">
            <!-- Content Header (Page header) -->
            <?php if (isset($component)) { $__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.content-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0)): ?>
<?php $attributes = $__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0; ?>
<?php unset($__attributesOriginal1107caaf3432fed2f91b2fcc2a154fe0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0)): ?>
<?php $component = $__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0; ?>
<?php unset($__componentOriginal1107caaf3432fed2f91b2fcc2a154fe0); ?>
<?php endif; ?>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <!-- Info boxes -->

                    <div class="row">

                        <div class="col-md-12">



                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Formulir Penambahan Pelanggan</h3>

                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <form method="POST" action="<?php echo e(route('addPelanggan')); ?>">
                                        <?php echo csrf_field(); ?>
                                    
                                        <!-- Pilihan Paket -->
                                        <fieldset class="border p-3 mb-3">
                                            <legend class="w-auto px-2">Pilih Paket</legend>
                                            <div class="form-group">
                                                <label for="pilihPaket">Pilih Paket</label>
                                                <select class="form-control" name="kodePaket" required>
                                                    <option value="">Pilih Paket</option>
                                                    <?php $__currentLoopData = $paketPPPoEs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($paket->kode_paket); ?>">
                                                            <?php echo e($paket->nama_paket); ?> - Rp. <?php echo e(number_format($paket->harga_paket, 0, ',', '.')); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="akunPppoe">Akun PPPoE</label>
                                                <input type="text" class="form-control" id="akunPppoe" name="akunPppoe" required placeholder="contoh:akun@123">
                                            </div>
                                            <div class="form-group">
                                                <label for="passwordPppoe">Password PPPoE</label>
                                                <input type="text" class="form-control" id="passwordPppoe" name="passwordPppoe" required placeholder="Password PPPoE">
                                            </div>
                                            <div class="form-group">
                                                <label for="passwordPppoe">SSID WiFI</label>
                                                <input type="text" class="form-control" id="ssid" name="ssid" required placeholder="SSID WiFi">
                                            </div>
                                            <div class="form-group">
                                                <label for="passwordPppoe">Password WiFI</label>
                                                <input type="text" class="form-control" id="passwifi" name="passwifi" required placeholder="Password WiFi">
                                            </div>
                                            
                                            
                                            <button type="button" class="btn btn-primary btn-block" id="toggleAdvance">Advance Form</button>
                                            
                                            <div id="advanceForm" style="display: none;">
                                                <div class="form-group">
                                                    <label for="passwordPppoe">Serial Number (Optional)</label>
                                                    <input type="text" class="form-control" id="serial" name="serialnumber" placeholder="Serial Number">
                                                </div>
                                                <div class="form-group">
                                                    <label for="passwordPppoe">MAC Address (Optional)</label>
                                                    <input type="text" class="form-control" id="macaddress" name="macaddress" placeholder="Mac Address">
                                                </div>
                                                <div class="form-group">
                                                    <label for="passwordPppoe">ODP (Optional)</label>
                                                    <input type="text" class="form-control" id="odp" name="odp" placeholder="ODP">
                                                </div>
                                                <div class="form-group">
                                                    <label for="passwordPppoe">OLT (Optional)</label>
                                                    <input type="text" class="form-control" id="olt" name="olt" placeholder="OLT">
                                                </div>
                                            </div>
                                            
                                        

                                        </fieldset>
                                    
                                        <!-- Informasi Pelanggan -->
                                        <fieldset class="border p-3 mb-3">
                                            <legend class="w-auto px-2">Informasi Pelanggan</legend>
                                            <div class="form-group">
                                                <label for="namaPelanggan">Nama Pelanggan</label>
                                                <input type="text" class="form-control" id="namaPelanggan" name="namaPelanggan" required placeholder="Nama Pelanggan">
                                            </div>

                                            <div class="form-group">
                                                <label for="telepon">Nomor Telepon</label>
                                                <input type="text" class="form-control" id="telepon" name="telepon" required placeholder="Nomor Telepon">
                                            </div>
                                            <div class="form-group">
                                                <label for="telepon">Tanggal Ingin Pasang</label>
                                                <input type="date" class="form-control" id="tanggalinginpasang" name="tip" required placeholder="Tanggal Ingin Pasang">
                                            </div>
                                            <div class="form-group">
                                                <label for="alamat">Alamat</label>
                                                <textarea class="form-control" id="alamat" name="alamat" required placeholder="Alamat"></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label for="tipePembayaran">Tipe Pembayaran</label>
                                                <select class="form-control" id="tipePembayaran" name="metode_pembayaran" required onchange="toggleInvoice()">
                                                    <option value="">Pilih Tipe Pembayaran</option>
                                                    <option value="Prabayar">Prabayar</option>
                                                    <option value="Pascabayar">Pascabayar</option>
                                                </select>
                                            </div>
                                        </fieldset>
                                    
                                        <!-- Invoice Section (Tampil Jika Prabayar) -->
                                        <fieldset class="border p-3 mb-3 d-none" id="invoiceSection">
                                            <legend class="w-auto px-2">Invoice</legend>
                                            <div class="form-group">
                                                <label for="invoiceAmount">Jumlah Tagihan</label>
                                                <input type="text" class="form-control" id="invoiceAmount" name="invoiceAmount" readonly>
                                            </div>
                                            <div class="form-group">
                                                <label for="invoiceDate">Tanggal Invoice</label>
                                                <input type="date" class="form-control" id="invoiceDate" name="invoiceDate" value="<?php echo e(date('Y-m-d')); ?>" readonly>
                                            </div>
                                        </fieldset>
                                    
                                        <button type="submit" class="btn btn-success">Tambah Pelanggan</button>
                                    </form>
                                    
                                    
                                    
                                </div>
                                <!-- /.card-body -->
                            </div>




                          


                        </div>


                    </div>


                </div>

            </section>
            <!-- /.content -->
        </div>

        <?php if (isset($component)) { $__componentOriginal10a5c05463c515701704e42d3b506416 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal10a5c05463c515701704e42d3b506416 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal10a5c05463c515701704e42d3b506416)): ?>
<?php $attributes = $__attributesOriginal10a5c05463c515701704e42d3b506416; ?>
<?php unset($__attributesOriginal10a5c05463c515701704e42d3b506416); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal10a5c05463c515701704e42d3b506416)): ?>
<?php $component = $__componentOriginal10a5c05463c515701704e42d3b506416; ?>
<?php unset($__componentOriginal10a5c05463c515701704e42d3b506416); ?>
<?php endif; ?>
    </div>
    <!-- ./wrapper -->

    <?php if (isset($component)) { $__componentOriginal4f8732821ff8626b580bba7a0c973801 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f8732821ff8626b580bba7a0c973801 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f8732821ff8626b580bba7a0c973801)): ?>
<?php $attributes = $__attributesOriginal4f8732821ff8626b580bba7a0c973801; ?>
<?php unset($__attributesOriginal4f8732821ff8626b580bba7a0c973801); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f8732821ff8626b580bba7a0c973801)): ?>
<?php $component = $__componentOriginal4f8732821ff8626b580bba7a0c973801; ?>
<?php unset($__componentOriginal4f8732821ff8626b580bba7a0c973801); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dhs.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dhs.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be)): ?>
<?php $attributes = $__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be; ?>
<?php unset($__attributesOriginald7827d4dd0764ad7ad1dfc1c365b25be); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be)): ?>
<?php $component = $__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be; ?>
<?php unset($__componentOriginald7827d4dd0764ad7ad1dfc1c365b25be); ?>
<?php endif; ?>

    <script>
        function toggleInvoice() {
            let tipe = document.getElementById("tipePembayaran").value;
            let invoiceSection = document.getElementById("invoiceSection");
    
            if (tipe === "prabayar") {
                invoiceSection.classList.remove("d-none");
                
                // Ambil harga dari paket yang dipilih
                let paketSelect = document.querySelector("[name='kodePaket']");
                let selectedOption = paketSelect.options[paketSelect.selectedIndex].text;
                let harga = selectedOption.match(/Rp\. ([\d.]+)/);
                
                if (harga) {
                    document.getElementById("invoiceAmount").value = harga[1].replace('.', '');
                }
            } else {
                invoiceSection.classList.add("d-none");
            }
        }
    </script>
     <script>
        $(document).ready(function() {
            $("#toggleAdvance").click(function() {
                $("#advanceForm").slideToggle();
            });
        });
    </script>
</body>

</html>
<?php /**PATH /home/lun4t1c/PROJECT/BILLER/resources/views/ROLE/MEMBER/PELANGGAN/formulir.blade.php ENDPATH**/ ?>